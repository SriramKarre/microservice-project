package com.example.movieratingservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.movieratingservice.entity.MovieRating;
import com.example.movieratingservice.service.MovieRatingService;

@RestController
public class MovieRatingController {

	@Autowired
	private MovieRatingService movieRatingService;

	@PostMapping("/saveMovieRating")
	public MovieRating saveMovieRating(@RequestBody MovieRating movieRating) {
		return movieRatingService.saveMovieRating(movieRating);
	}

	@GetMapping("/getMovieRatingByUsingRatingId/{ratingId}")
	public List<MovieRating> getMovieRatingByUsingRatingId(@PathVariable("ratingId") int ratingId) {
		return movieRatingService.getMovieRatingByUsingRatingId(ratingId);
	}

	@GetMapping("/getMovieRatingByUsingMovieId/{movieId}")
	public List<MovieRating> getMovieRatingByUsingMovieId(@PathVariable("movieId") int movieId) {
		return movieRatingService.getMovieRatingByUsingMovieId(movieId);
	}

	@GetMapping("/getMovieRatingByUsingMovieInfoId/{movieInfoId}")
	public List<MovieRating> getMovieRatingByUsingMovieInfoId(@PathVariable("movieInfoId") int movieInfoId) {
		return movieRatingService.getMovieRatingByUsingMovieInfoId(movieInfoId); // Corrected method call
	}

	@GetMapping("/getAllMovieRatings")
	public List<MovieRating> getAllMovieRatings() {
		return movieRatingService.getAllMovieRatings();
	}
}