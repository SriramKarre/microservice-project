package com.example.moviecatalogservice.serviceimpl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.moviecatalogservice.entity.Movie;
import com.example.moviecatalogservice.entity.MovieInfo;
import com.example.moviecatalogservice.entity.MovieRating;
import com.example.moviecatalogservice.repository.MovieRepository;
import com.example.moviecatalogservice.service.MovieService;

@Service
public class MovieServiceImpl implements MovieService {
	@Autowired
	private MovieRepository movieRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Movie saveMovie(Movie movie) {
		// TODO Auto-generated method stub
		return movieRepository.save(movie);
	}

	@Override
	public Movie getMovieByUsingMovieId(int movieId) {
		// TODO Auto-generated method stub
		MovieInfo[] infos = restTemplate.getForObject("http://MOVIE-INFO-SERVICE:8187/getMovieInfoByUsingMovieId/" + movieId,
				MovieInfo[].class);
		List<MovieInfo> movieInfo = Arrays.asList(infos);

		Movie movie = movieRepository.findById(movieId).get();
		movie.setMovieInfoList(movieInfo);

		MovieRating[] movieRating = restTemplate
				.getForObject("http://MOVIE-RATING-SERVICE:8188/getMovieRatingByUsingMovieId/" + movieId, MovieRating[].class);

		List<MovieRating> movieRatings = Arrays.asList(movieRating);
		movie.setMovieRatingList(movieRatings);

		return movie;
	}

	@Override
	public List<Movie> getAllMovies() {
		// TODO Auto-generated method stub
		return movieRepository.findAll();
	}

}