package com.example.moviecatalogservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.moviecatalogservice.entity.Movie;
@Repository
public interface MovieRepository extends JpaRepository<Movie, Integer> {

}