package com.example.movieinfoservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.movieinfoservice.entity.MovieInfo;
import com.example.movieinfoservice.service.MovieInfoService;

@RestController
public class MovieInfoController {
	@Autowired
	private MovieInfoService movieInfoService;

	@PostMapping("/saveMovieInfo")
	public MovieInfo saveMovieInfo(@RequestBody MovieInfo movieInfo) {
		return movieInfoService.saveMovieInfo(movieInfo);
	}

	@GetMapping("/getMovieInfoByUsingMovieInfoId/{movieInfoId}")
	public List<MovieInfo> getMovieInfoByUsingMovieInfoId(@PathVariable("movieInfoId") int movieInfoId) {
		return movieInfoService.getMovieInfoByUsingMovieId(movieInfoId);
	}

	@GetMapping("/getMovieInfoByUsingMovieId/{movieId}")
	public List<MovieInfo> getMovieInfoByUsingMovieId(@PathVariable("movieId") int movieId) {
		return movieInfoService.getMovieInfoByUsingMovieId(movieId);
	}

	@GetMapping("/getAllMovieInfo")
	public List<MovieInfo> getAllMovieInfo() {
		return movieInfoService.getAllMovieInfo();
	}
}