package com.example.movieinfoservice.service;

import java.util.List;

import com.example.movieinfoservice.entity.MovieInfo;

public interface MovieInfoService {
	public MovieInfo saveMovieInfo(MovieInfo movieInfo);

	public List<MovieInfo> getMovieInfoByUsingMovieInfoId(int movieInfoId);

	public List<MovieInfo> getMovieInfoByUsingMovieId(int movieId);

	public List<MovieInfo> getAllMovieInfo();

}